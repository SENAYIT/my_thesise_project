from RPLCD import CharLCD
from RPi import GPIO
import time  
def lcdwrite(text,clear=0):
    lcd = CharLCD(numbering_mode=GPIO.BOARD, cols=20, rows=4, pin_rs=37, pin_e=35, pins_data=[33, 31, 29, 23])

    if clear==1:
       lcd.clear()
    lcd.write_string(text)
    return
