cd /
cd /home/pi/facial_recognition/

sudo python start.py
cd /
