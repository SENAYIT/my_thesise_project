from RPLCD import CharLCD
from RPi import GPIO
import shutil
import os
import time
import json
from keypad import keypad
from train_model import trainmodel
from headshots import headshots
from facial_rec import face_rec
lcd = CharLCD(numbering_mode=GPIO.BOARD, cols=20, rows=4, pin_rs=37, pin_e=35, pins_data=[33, 31, 29, 23])
GPIO.setmode(GPIO.BOARD)
door=7
buzzer=11
GPIO.setup(door, GPIO.OUT)  # Set pin as an output
GPIO.setup(buzzer, GPIO.OUT)
def switchdoor(status):
    global door
    time.sleep(1)
    if status ==0:
        lcd.clear()
        GPIO.output(door,True)
        time.sleep(1)
        GPIO.output(door,False)
        time.sleep(0.2)
        lcd.clear()
    else:
        lcd.clear()
        GPIO.output(door,True)
        time.sleep(1)
        GPIO.output(door,False)
        time.sleep(0.2)
        lcd.clear()
    lcd.clear()   
    return
def alarm():
    global buzzer
    buzzes=10
    
    while buzzes >0:
        GPIO.output(buzzer,True)
        time.sleep(0.5)
        GPIO.output(buzzer,False)
        time.sleep(0.5)
        buzzes-=1
    return

def lcdwrite(text,clear=0):

    if clear==1:
       lcd.clear()
    lcd.write_string(text)
    return
kp=keypad(columnCount = 4)
datapath="./pindata/data_file.json"
data={}
def updatedata():
    global data
    with open(datapath, "w") as write_file:
        json.dump(data, write_file)
    readdata()
def readdata():
    global data
    try:
        
        with open(datapath, "r") as read_file:
            data = json.load(read_file)
    except:
        data={}
        updatedata()

def getdigit():
        time.sleep(0.2)
        digit = None
        while digit == None:
            digit = kp.getKey()

        return str(digit)  
def getpin(prompt,pinlength=4):
    lcdwrite(prompt,1)
    time.sleep(0.2)
    pin=""

    while len(pin)<pinlength:
        
        digit = None
        while digit == None:
            digit = kp.getKey()
        pin+=str(digit)
        lcdwrite(str(digit))
        time.sleep(0.3)
    return pin
def start():
    global data
    readdata()
    if "admin" not in data.keys():
        data["admin"]="1234"
        updatedata()
        
    print(data["admin"])
    attempts=0
    while 1:
        if attempts>2:
            lcdwrite("timeout",1)
            alarm()
            time.sleep(90)
            attempts=0
        lcdwrite("press any key toface unlock,* to use pin,r# to change pin,0 to register ",1)
        choice=getdigit()
        if choice== "#":
           oldpin= getpin("enter old pin\n\r:")
           usertochange=None
           for name, pin in data.items():
                 if pin == oldpin and name !="admin":
                     usertochange=name
           if usertochange==None:
                attempts+=1
                lcdwrite("unknown pin",1)
                time.sleep(0.5)
                continue
           newpin=getpin("enter new pin\n\r:")
           if newpin==getpin("repeat pin\n\r:"):
                userface=face_rec()
                if userface!=usertochange:
                    lcdwrite("face mismatch",1)
                    time.sleep(0.5)
                    continue
                else:
                    readdata()
                    data[usertochange]=newpin
                    updatedata()
                    lcdwrite("pin changed successfully",1)
                    time.sleep(1)
                    
           else:
                lcdwrite("error",1)
                time.sleep(0.5)
                continue
                
                
        

        elif choice =="*":
             searchpin=getpin("enter pin \n\r:")
             pinaccepted=0
             for name, pin in data.items():
                 if pin == searchpin:
                    pinaccepted=1
             if pinaccepted:
             
                lcdwrite("Autorized,welcome",1)
                attempts=0
                switchdoor(1)
                time.sleep(5)
                switchdoor(0)
             else:
                 lcdwrite("unknown pin",1)
                 time.sleep(0.5)
                 attempts+=1
        elif choice=="0":
            newuser="user"+str(len(data))
            if headshots(newuser)==0:
                lcdwrite("canceled",1)
                newpath = r'./dataset/'+str(newuser) 
                if  os.path.exists(newpath):
                   shutil.rmtree(newpath)
                time.sleep(0.5)
                continue
            newpin=getpin("enter your new pin\n\r:")
            if newpin==getpin("repeat pin\n\r:") :
                admin=getpin("enter admin pin to complete\n\r:")
                for name, pin in data.items():
                 if name == "admin"and pin==admin:
                    readdata()
                    data[newuser]=newpin
                    updatedata()
                    lcdwrite("registering please wait",1)
                    trainmodel()
                    lcdwrite("registered",1)
                    time.sleep(1)
                    
                 else:
                     lcdwrite("Error",1)
                     time.sleep(0.5)
                     attempts+=1
                
                
        else:
            person= face_rec()
            if person in data:
                lcdwrite("Autorized,welcome",1)
                switchdoor(1)
                      
                time.sleep(5)
                switchdoor(0)
                    
                attempts=0
            else:
                     lcdwrite("unknown face",1)
                     time.sleep(1)
            




start()