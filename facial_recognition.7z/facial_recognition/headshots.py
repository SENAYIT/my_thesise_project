import cv2
import time
import os
import face_recognition
from lcd import lcdwrite
from keypad import keypad
kp=keypad(columnCount = 4)

def getdigit():
        digit = None
        while digit == None:
            digit = kp.getKey()
        print("pressed")
        return str(digit)

def headshots(name):
    newpath = r'./dataset/'+str(name) 
    if not os.path.exists(newpath):
        os.makedirs(newpath)    
    cam = cv2.VideoCapture(0)

   

    img_counter = 0

    while img_counter<10:
        ret, frame = cam.read()
        if not ret:
            print("failed to grab frame")
            break
        
        lcdwrite("stand infront of the camera,and press any ke to take a shot,# to cancel",1)
        if getdigit()=="#":
            
         return(0)
        
        
        
       
        boxes = face_recognition.face_locations(frame)
        if len(boxes) == 0:
            lcdwrite("stand 1 meter from the camera and look straight at it",1)
            time.sleep(1)
        else:
                img_name = "dataset/"+ name +"/image_{}.jpg".format(img_counter)
                cv2.imwrite(img_name, frame)
                print("{} written!".format(img_name))
                lcdwrite("captured,move your face slightly for another one",1)
                time.sleep(1)
                img_counter += 1

    cam.release()

    cv2.destroyAllWindows()
    lcdwrite("face registration sucessful",1)
    time.sleep(1)
    return(1)

