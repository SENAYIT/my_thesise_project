import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BOARD)
GPIO.setup(7, GPIO.OUT)  # Set pin as an output
GPIO.setup(11, GPIO.OUT)  # Set pin as an output

GPIO.output(7, False)
GPIO.output(11, False)
